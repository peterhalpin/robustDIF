test_that("y_fun validates `fun`", {
  expect_error(
    y_fun(mle = rdif.eg, fun = "bad_fun"),
    "`fun` must be one of"
  )
})

test_that("vcov_y validates theta when provided", {
  expect_error(
    vcov_y(mle = rdif.eg, theta = c(0, 1), fun = "d_fun3"),
    "`theta` must be a single finite numeric value"
  )
})

test_that("rdif validates key control inputs", {
  expect_error(
    rdif(mle = rdif.eg, alpha = 1.1),
    "`alpha` must be a single numeric value in"
  )
  expect_error(
    rdif(mle = rdif.eg, method = "newton"),
    "Only `method = 'irls'` is currently implemented"
  )
  expect_error(
    rdif(mle = rdif.eg, starting.value = "bad_start"),
    "`starting.value` must be one of"
  )
  expect_error(
    rdif(mle = rdif.eg, maxit = 0),
    "`maxit` must be a single positive integer"
  )
})

test_that("rho_grid validates grid controls", {
  expect_error(
    rho_grid(mle = rdif.eg, alpha = -0.1),
    "`alpha` must be a single numeric value in"
  )
  expect_error(
    rho_grid(mle = rdif.eg, grid.width = 0),
    "`grid.width` must be a single positive finite numeric value"
  )
})

test_that("dif_test and delta_test validate required inputs", {
  expect_error(
    dif_test(object = rdif.eg, theta = c(0, 1)),
    "`theta` must be a single finite numeric value"
  )
  expect_error(
    delta_test(object = rdif.eg, theta = 0, k = -1),
    "`k` must be a single positive finite numeric value"
  )
})

test_that("delta_test accepts rdif object and returns stored output", {
  mod <- rdif(mle = rdif.eg)
  out <- delta_test(mod)
  expect_s3_class(out, "data.frame")
  expect_equal(out, mod$delta.test)
})

test_that("dif_test accepts rdif object and returns stored output", {
  mod <- rdif(mle = rdif.eg)
  out <- dif_test(mod)
  expect_s3_class(out, "data.frame")
  expect_equal(out, mod$dif.test)
})

test_that("get_model_parms validates object class and structure", {
  expect_error(
    get_model_parms(object = 1),
    "`object` must be either"
  )
  expect_error(
    get_model_parms(object = list()),
    "non-empty list"
  )
  expect_error(
    get_model_parms(object = list(1, 2)),
    "must contain model fits"
  )
})
