library(testthat)
library(robustDIF)

test_check("robustDIF")
